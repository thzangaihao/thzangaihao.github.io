"""培养皿自动定位与 1:1 批量裁剪工具。

双击运行会打开图形界面；也可在终端中批量调用：
    python 1.py "示例输入" -o "裁剪结果"
"""

from __future__ import annotations

import argparse
import csv
import math
import sys
from pathlib import Path

import cv2
import numpy as np


IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}


def measure_colony(
    image: np.ndarray,
    circle: tuple[float, float, float],
    dish_diameter_mm: float,
    analysis_max: int = 900,
) -> dict | None:
    """分割皿内中央菌落，并按十字法测量水平径、垂直径及二者均值。

    算法从培养基外圈自动估计背景颜色，使用 Lab 色差分离菌落，因此同时
    适用于白色、浅色和有色菌落。返回的坐标均位于原始图像坐标系中。
    """
    cx, cy, radius = circle
    h, w = image.shape[:2]
    scale = min(1.0, analysis_max / max(2 * radius, 1))
    x1, y1 = max(0, int(cx-radius)), max(0, int(cy-radius))
    x2, y2 = min(w, int(cx+radius)+1), min(h, int(cy+radius)+1)
    roi = image[y1:y2, x1:x2]
    if roi.size == 0:
        return None
    small = cv2.resize(roi, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    sh, sw = small.shape[:2]
    scx, scy = (cx-x1)*scale, (cy-y1)*scale
    sr = radius*scale
    yy, xx = np.ogrid[:sh, :sw]
    distance_from_center = np.sqrt((xx-scx)**2 + (yy-scy)**2)

    lab = cv2.cvtColor(small, cv2.COLOR_BGR2LAB).astype(np.float32)
    # 0.60–0.78R 通常是培养基、且避开培养皿边缘。
    background_ring = (distance_from_center >= sr*.60) & (distance_from_center <= sr*.78)
    if background_ring.sum() < 100:
        return None
    background = np.median(lab[background_ring], axis=0)
    color_distance = np.linalg.norm(lab-background, axis=2)
    inner = distance_from_center <= sr*.72
    values = np.clip(color_distance[inner], 0, 255).astype(np.uint8)
    if values.size < 100:
        return None
    otsu, _ = cv2.threshold(values.reshape(-1, 1), 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
    threshold = max(10.0, float(otsu))
    mask = ((color_distance >= threshold) & inner).astype(np.uint8)*255

    kernel_size = max(3, int(sr*.018) | 1)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
    count, labels, stats, centers = cv2.connectedComponentsWithStats(mask, 8)
    candidates = []
    dish_area = math.pi*sr*sr
    for label in range(1, count):
        area = stats[label, cv2.CC_STAT_AREA]
        bx, by, bw, bh = stats[label, :4]
        px, py = centers[label]
        center_distance = math.hypot(px-scx, py-scy)/max(sr, 1)
        area_ratio = area/max(dish_area, 1)
        if .002 <= area_ratio <= .55 and center_distance <= .45:
            candidates.append((area*(1.5-center_distance), label, bx, by, bw, bh, px, py, area))
    if not candidates:
        return None
    _, label, bx, by, bw, bh, px, py, area = max(candidates)

    # 十字测量法：水平方向与垂直方向最大跨度，最终直径取二者均值。
    width_px = bw/scale
    height_px = bh/scale
    mean_px = (width_px+height_px)/2
    mm_per_px = dish_diameter_mm/(2*radius)
    return {
        "bbox": (x1+bx/scale, y1+by/scale, width_px, height_px),
        "center": (x1+px/scale, y1+py/scale),
        "horizontal_px": width_px,
        "vertical_px": height_px,
        "mean_px": mean_px,
        "horizontal_mm": width_px*mm_per_px,
        "vertical_mm": height_px*mm_per_px,
        "mean_mm": mean_px*mm_per_px,
        "area_px": area/(scale*scale),
        "threshold": threshold,
    }


def read_image(path: Path) -> np.ndarray:
    """兼容含中文字符的 Windows 路径。"""
    data = np.fromfile(str(path), dtype=np.uint8)
    image = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError("无法读取图片")
    return image


def write_image(path: Path, image: np.ndarray, quality: int = 95) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    suffix = path.suffix.lower()
    ext = suffix if suffix in {".jpg", ".jpeg", ".png", ".webp"} else ".png"
    params = [cv2.IMWRITE_JPEG_QUALITY, quality] if ext in {".jpg", ".jpeg"} else []
    ok, encoded = cv2.imencode(ext, image, params)
    if not ok:
        raise ValueError("图片编码失败")
    encoded.tofile(str(path))


def _circle_edge_score(gray: np.ndarray, circle: np.ndarray) -> float:
    """用圆周梯度给 Hough 候选打分，排除标签和菌落等伪圆。"""
    x, y, r = circle
    gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
    magnitude = cv2.magnitude(gx, gy)
    angles = np.linspace(0, 2 * np.pi, 240, endpoint=False)
    scores = []
    for radius_factor in (0.94, 0.98, 1.02, 1.06):
        xs = np.rint(x + r * radius_factor * np.cos(angles)).astype(int)
        ys = np.rint(y + r * radius_factor * np.sin(angles)).astype(int)
        valid = (xs >= 0) & (xs < gray.shape[1]) & (ys >= 0) & (ys < gray.shape[0])
        if valid.mean() < 0.88:
            return -1.0
        scores.append(float(np.mean(magnitude[ys[valid], xs[valid]])))
    # 培养皿应尽可能大；轻微奖励大半径能避免把菌落误认为皿边。
    return max(scores) + 18.0 * r / min(gray.shape)


def detect_dish(image: np.ndarray, preview_max: int = 1200) -> tuple[float, float, float]:
    """返回原图坐标系中的 (圆心 x, 圆心 y, 半径)。"""
    height, width = image.shape[:2]
    scale = min(1.0, preview_max / max(height, width))
    small = cv2.resize(image, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (9, 9), 2.0)
    short_side = min(gray.shape)

    candidates: list[np.ndarray] = []
    # 多个阈值可适应透明皿、浅色培养基和不同曝光。
    for accumulator_threshold in (58, 50, 43, 36):
        circles = cv2.HoughCircles(
            gray,
            cv2.HOUGH_GRADIENT,
            dp=1.2,
            minDist=short_side * 0.35,
            param1=110,
            param2=accumulator_threshold,
            minRadius=int(short_side * 0.25),
            maxRadius=int(short_side * 0.49),
        )
        if circles is not None:
            candidates.extend(circles[0])
        if len(candidates) >= 3:
            break

    if not candidates:
        raise ValueError("未检测到培养皿（请确保皿边完整、清晰且与背景有对比）")

    best = max(candidates, key=lambda c: _circle_edge_score(gray, c))
    return float(best[0] / scale), float(best[1] / scale), float(best[2] / scale)


def crop_square(
    image: np.ndarray,
    circle: tuple[float, float, float],
    margin: float = 0.03,
    output_size: int = 0,
) -> np.ndarray:
    """围绕圆心裁出正方形；靠近照片边缘时自动补黑，不切掉培养皿。"""
    cx, cy, radius = circle
    half = radius * (1.0 + margin)
    side = max(2, int(round(half * 2)))
    left = int(round(cx - side / 2))
    top = int(round(cy - side / 2))
    right, bottom = left + side, top + side

    h, w = image.shape[:2]
    result = np.zeros((side, side, 3), dtype=image.dtype)
    src_l, src_t = max(0, left), max(0, top)
    src_r, src_b = min(w, right), min(h, bottom)
    if src_r <= src_l or src_b <= src_t:
        raise ValueError("检测圆位于图片范围之外")
    result[src_t - top : src_b - top, src_l - left : src_r - left] = image[src_t:src_b, src_l:src_r]

    if output_size > 0 and side != output_size:
        interpolation = cv2.INTER_AREA if side > output_size else cv2.INTER_CUBIC
        result = cv2.resize(result, (output_size, output_size), interpolation=interpolation)
    return result


def process_folder(
    input_dir: Path,
    output_dir: Path,
    margin: float = 0.03,
    output_size: int = 0,
    overwrite: bool = False,
    dish_diameter_mm: float = 90.0,
    progress=None,
) -> tuple[int, list[str]]:
    input_dir, output_dir = input_dir.resolve(), output_dir.resolve()
    if input_dir == output_dir:
        raise ValueError("输入和输出文件夹不能相同")
    files = sorted(p for p in input_dir.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_SUFFIXES)
    if not files:
        raise ValueError("输入文件夹中没有支持的图片")

    output_dir.mkdir(parents=True, exist_ok=True)
    success, errors, records = 0, [], []
    for index, source in enumerate(files, 1):
        target = output_dir / f"{source.stem}.png"
        try:
            if target.exists() and not overwrite:
                raise FileExistsError("输出已存在（使用 --overwrite 覆盖）")
            image = read_image(source)
            circle = detect_dish(image)
            colony = measure_colony(image, circle, dish_diameter_mm)
            cropped = crop_square(image, circle, margin, output_size)
            write_image(target, cropped)
            success += 1
            if colony:
                records.append({
                    "文件名": source.name,
                    "培养皿直径_mm": f"{dish_diameter_mm:.3f}",
                    "培养皿直径_px": f"{circle[2]*2:.1f}",
                    "菌落水平径_px": f"{colony['horizontal_px']:.1f}",
                    "菌落垂直径_px": f"{colony['vertical_px']:.1f}",
                    "菌落平均直径_px": f"{colony['mean_px']:.1f}",
                    "菌落水平径_mm": f"{colony['horizontal_mm']:.3f}",
                    "菌落垂直径_mm": f"{colony['vertical_mm']:.3f}",
                    "菌落平均直径_mm": f"{colony['mean_mm']:.3f}",
                    "测量状态": "成功",
                })
                message = (f"[{index}/{len(files)}] 完成：{source.name} "
                           f"菌落 {colony['mean_mm']:.2f} mm")
            else:
                records.append({
                    "文件名": source.name,
                    "培养皿直径_mm": f"{dish_diameter_mm:.3f}",
                    "培养皿直径_px": f"{circle[2]*2:.1f}",
                    "测量状态": "未识别到菌落",
                })
                message = f"[{index}/{len(files)}] 完成：{source.name}（未识别到菌落）"
        except Exception as exc:
            errors.append(f"{source.name}: {exc}")
            message = f"[{index}/{len(files)}] 失败：{source.name} - {exc}"
        if progress:
            progress(message)
        else:
            print(message)
    csv_path = output_dir / "菌落测量记录.csv"
    fields = ["文件名", "培养皿直径_mm", "培养皿直径_px", "菌落水平径_px",
              "菌落垂直径_px", "菌落平均直径_px", "菌落水平径_mm",
              "菌落垂直径_mm", "菌落平均直径_mm", "测量状态"]
    with csv_path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)
    return success, errors


def launch_gui() -> None:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    root = tk.Tk()
    root.title("培养皿智能裁剪")
    root.geometry("650x420")
    root.minsize(560, 360)

    input_var, output_var = tk.StringVar(), tk.StringVar()
    margin_var = tk.StringVar(value="3")
    dish_mm_var = tk.StringVar(value="90")

    panel = ttk.Frame(root, padding=18)
    panel.pack(fill="both", expand=True)
    ttk.Label(panel, text="培养皿智能裁剪", font=("Microsoft YaHei UI", 17, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 16))

    def choose_input() -> None:
        path = filedialog.askdirectory(title="选择包含原图的文件夹")
        if path:
            input_var.set(path)
            if not output_var.get():
                output_var.set(str(Path(path).parent / "裁剪结果"))

    def choose_output() -> None:
        path = filedialog.askdirectory(title="选择输出文件夹")
        if path:
            output_var.set(path)

    ttk.Label(panel, text="输入文件夹").grid(row=1, column=0, sticky="w", pady=5)
    ttk.Entry(panel, textvariable=input_var).grid(row=1, column=1, sticky="ew", padx=8)
    ttk.Button(panel, text="选择…", command=choose_input).grid(row=1, column=2)
    ttk.Label(panel, text="输出文件夹").grid(row=2, column=0, sticky="w", pady=5)
    ttk.Entry(panel, textvariable=output_var).grid(row=2, column=1, sticky="ew", padx=8)
    ttk.Button(panel, text="选择…", command=choose_output).grid(row=2, column=2)
    ttk.Label(panel, text="外缘留白 (%)").grid(row=3, column=0, sticky="w", pady=5)
    ttk.Entry(panel, textvariable=margin_var, width=10).grid(row=3, column=1, sticky="w", padx=8)
    ttk.Label(panel, text="输出分辨率").grid(row=4, column=0, sticky="w", pady=5)
    ttk.Label(panel, text="跟随原图（仅裁剪，不缩放）").grid(row=4, column=1, sticky="w", padx=8)
    ttk.Label(panel, text="培养皿直径 (mm)").grid(row=5, column=0, sticky="w", pady=5)
    ttk.Entry(panel, textvariable=dish_mm_var, width=10).grid(row=5, column=1, sticky="w", padx=8)

    log = tk.Text(panel, height=9, state="disabled", font=("Consolas", 9))
    log.grid(row=7, column=0, columnspan=3, sticky="nsew", pady=(14, 0))

    def append_log(message: str) -> None:
        log.configure(state="normal")
        log.insert("end", message + "\n")
        log.see("end")
        log.configure(state="disabled")
        root.update_idletasks()

    def run() -> None:
        try:
            source, target = Path(input_var.get()), Path(output_var.get())
            if not source.is_dir() or not output_var.get():
                raise ValueError("请先选择有效的输入和输出文件夹")
            margin = float(margin_var.get()) / 100
            dish_mm = float(dish_mm_var.get())
            if not 0 <= margin <= 0.3:
                raise ValueError("留白须为 0–30%")
            if not 10 <= dish_mm <= 500:
                raise ValueError("培养皿直径须在 10–500 mm 之间")
            run_button.configure(state="disabled")
            count, errors = process_folder(source, target, margin, 0, True, dish_mm, append_log)
            messagebox.showinfo("处理完成", f"成功 {count} 张，失败 {len(errors)} 张。\n裁图和菌落测量 CSV：{target}")
        except Exception as exc:
            messagebox.showerror("无法处理", str(exc))
        finally:
            run_button.configure(state="normal")

    run_button = ttk.Button(panel, text="开始批量裁剪", command=run)
    run_button.grid(row=6, column=0, columnspan=3, pady=(15, 0))
    panel.columnconfigure(1, weight=1)
    panel.rowconfigure(7, weight=1)
    root.mainloop()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="自动检测培养皿并批量裁为 1:1 正方形")
    parser.add_argument("input", nargs="?", type=Path, help="输入图片文件夹；省略则打开图形界面")
    parser.add_argument("-o", "--output", type=Path, default=Path("裁剪结果"), help="输出文件夹")
    parser.add_argument("--margin", type=float, default=3.0, help="培养皿外缘留白百分比，默认 3")
    parser.add_argument("--size", type=int, default=0, help="输出正方形边长；默认 0，按原图保留裁剪分辨率")
    parser.add_argument("--dish-mm", type=float, default=90.0, help="培养皿实际直径（毫米），默认 90")
    parser.add_argument("--overwrite", action="store_true", help="覆盖已有输出")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.input is None:
        launch_gui()
        return 0
    try:
        if not args.input.is_dir():
            raise ValueError(f"输入文件夹不存在：{args.input}")
        if not 0 <= args.margin <= 30:
            raise ValueError("--margin 须在 0 到 30 之间")
        if args.size != 0 and args.size < 64:
            raise ValueError("--size 须为 0 或不小于 64")
        if not 10 <= args.dish_mm <= 500:
            raise ValueError("--dish-mm 须在 10 到 500 之间")
        success, errors = process_folder(args.input, args.output, args.margin / 100,
                                         args.size, args.overwrite, args.dish_mm)
        print(f"\n处理结束：成功 {success} 张，失败 {len(errors)} 张，输出至 {args.output.resolve()}")
        return 1 if errors else 0
    except Exception as exc:
        print(f"错误：{exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

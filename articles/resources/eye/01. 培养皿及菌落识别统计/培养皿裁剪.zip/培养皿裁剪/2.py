"""手机/网络摄像头培养皿实时识别、预览与捕获。"""
from __future__ import annotations

import os, queue, threading, time, tkinter as tk
from datetime import datetime
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from tkinter import messagebox, ttk

import cv2
import numpy as np
from PIL import Image, ImageTk

HERE = Path(__file__).resolve().parent
spec = spec_from_file_location("dish_core", HERE / "1.py")
core = module_from_spec(spec)
spec.loader.exec_module(core)


class Stream:
    """后台持续读取，只向界面交付最新帧，避免网络积帧。"""
    def __init__(self, source: str, events: queue.Queue):
        self.source, self.events = source, events
        self.stop_event = threading.Event()
        self.cap = None

    def start(self):
        threading.Thread(target=self.run, daemon=True).start()

    def stop(self):
        self.stop_event.set()
        if self.cap is not None:
            self.cap.release()

    def send(self, kind, data=None):
        try:
            while self.events.qsize() > 1:
                self.events.get_nowait()
            self.events.put_nowait((kind, data))
        except queue.Full:
            pass

    def run(self):
        source = int(self.source) if self.source.isdigit() else self.source
        self.cap = cv2.VideoCapture(source)
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        if not self.cap.isOpened():
            self.send("error", "无法打开视频流，请检查地址、手机串流服务和防火墙。")
            return
        self.send("connected")
        failed = 0
        while not self.stop_event.is_set():
            ok, frame = self.cap.read()
            if ok:
                failed = 0
                self.send("frame", (frame, time.perf_counter()))
            else:
                failed += 1
                if failed > 30:
                    self.send("error", "视频流已中断。")
                    break
                time.sleep(.03)
        self.cap.release()


def detect(frame):
    """实时版大圆检测，返回原始视频坐标。"""
    h, w = frame.shape[:2]
    scale = min(1., 720 / max(h, w))
    small = cv2.resize(frame, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    gray = cv2.GaussianBlur(cv2.cvtColor(small, cv2.COLOR_BGR2GRAY), (9, 9), 2)
    short = min(gray.shape)
    found = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, 1.25, short * .4,
                             param1=105, param2=42,
                             minRadius=int(short * .2), maxRadius=int(short * .49))
    if found is None:
        return None
    x, y, r = max(found[0], key=lambda c: c[2])
    return x / scale, y / scale, r / scale


def dashed_line(image, start, end, color, thickness=2, dash=8, gap=6):
    """使用固定显示像素绘制虚线。"""
    x1, y1 = start; x2, y2 = end
    length = max(1.0, ((x2-x1)**2+(y2-y1)**2)**.5)
    dx, dy = (x2-x1)/length, (y2-y1)/length
    position = 0.0
    while position < length:
        finish = min(length, position+dash)
        a = (int(x1+dx*position), int(y1+dy*position))
        b = (int(x1+dx*finish), int(y1+dy*finish))
        cv2.line(image, a, b, color, thickness, cv2.LINE_AA)
        position += dash+gap


def dashed_rectangle(image, left, top, right, bottom, color):
    dashed_line(image, (left,top), (right,top), color)
    dashed_line(image, (right,top), (right,bottom), color)
    dashed_line(image, (right,bottom), (left,bottom), color)
    dashed_line(image, (left,bottom), (left,top), color)


class App:
    # 接近 VS Code Dark+：灰黑底、低饱和边框、蓝色强调。
    BG, PANEL, CYAN, GREEN = "#181818", "#252526", "#4fc1ff", "#89d185"

    def __init__(self, root):
        self.root = root
        root.title("DISH VISION · 培养皿实时识别")
        root.geometry("1180x760"); root.minsize(900, 620); root.configure(bg=self.BG)
        self.events = queue.Queue(4); self.stream = None; self.frame = None
        self.circle = None; self.last_seen = self.last_frame = self.fps = 0.
        self.bitrate_mbps = 0.
        self.counter = 0; self.photo = None; self.colony = None
        self.output = HERE / "实时捕获"
        self.url = tk.StringVar(value="http://192.168.1.100:8080/video")
        self.status = tk.StringVar(value="STANDBY  等待连接")
        self.detail = tk.StringVar(value="未检测到培养皿")
        self.dish_mm = tk.StringVar(value="90")
        self.build(); root.after(15, self.poll); root.protocol("WM_DELETE_WINDOW", self.close)

    def build(self):
        s = ttk.Style(); s.theme_use("clam")
        s.configure("TFrame", background=self.BG); s.configure("Panel.TFrame", background=self.PANEL)
        s.configure("TLabel", background=self.BG, foreground="#cccccc", font=("Microsoft YaHei UI", 10))
        s.configure("Title.TLabel", foreground=self.CYAN, font=("Segoe UI", 20, "bold"))
        s.configure("Accent.TButton", background="#0e639c", foreground="white", padding=8)
        s.map("Accent.TButton", background=[("active", "#1177bb")])
        s.configure("Dark.TButton", background="#333333", foreground="#dddddd", padding=8)
        s.map("Dark.TButton", background=[("active", "#454545")])

        top = ttk.Frame(self.root, padding=(14, 8)); top.pack(fill="x")
        ttk.Label(top, text="DISH VISION", style="Title.TLabel").pack(side="left")
        ttk.Label(top, text="  实时培养皿视觉工作台", foreground="#858585").pack(side="left")
        self.status_label = tk.Label(top, textvariable=self.status, bg=self.BG, fg=self.GREEN,
                                     font=("Consolas", 10, "bold"))
        self.status_label.pack(side="right")
        bar = ttk.Frame(self.root, padding=(14, 0, 14, 8)); bar.pack(fill="x")
        ttk.Label(bar, text="串流地址").pack(side="left")
        self.entry = tk.Entry(bar, textvariable=self.url, bg="#3c3c3c", fg="#eeeeee",
                              insertbackground="white", relief="flat", font=("Consolas", 10),
                              highlightthickness=1, highlightbackground="#555555")
        self.entry.pack(side="left", fill="x", expand=True, padx=10, ipady=8)
        self.connect_btn = ttk.Button(bar, text="连接视频流", style="Accent.TButton", command=self.toggle)
        self.connect_btn.pack(side="left", padx=(0, 8))
        ttk.Button(bar, text="捕获画面", style="Dark.TButton", command=self.capture).pack(side="left", padx=(0, 8))
        ttk.Label(bar, text="培养皿直径 mm").pack(side="left")
        self.dish_entry = tk.Entry(bar, textvariable=self.dish_mm, width=6, bg="#3c3c3c", fg="#eeeeee",
                                   insertbackground="white", relief="flat", font=("Consolas", 10))
        self.dish_entry.pack(side="left", padx=(6, 8), ipady=8)
        ttk.Button(bar, text="打开目录", style="Dark.TButton", command=self.open_folder).pack(side="left")

        body = ttk.Frame(self.root, padding=(8, 0, 8, 8)); body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=1); body.rowconfigure(0, weight=1)
        self.canvas = tk.Canvas(body, bg="#0d0d0d", highlightbackground="#3f3f46", highlightthickness=1)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.canvas.create_text(400, 280, text="NO SIGNAL\n\n输入手机串流地址并连接", fill="#35535f",
                                font=("Segoe UI", 17), justify="center")

    def toggle(self):
        if self.stream:
            self.disconnect(); return
        source = self.url.get().strip()
        if not source:
            messagebox.showwarning("缺少地址", "请输入内网串流地址或摄像头编号。")
            return
        self.status.set("CONNECTING  正在连接…"); self.entry.config(state="disabled")
        self.connect_btn.config(text="断开连接"); self.stream = Stream(source, self.events); self.stream.start()

    def disconnect(self):
        if self.stream: self.stream.stop()
        self.stream = self.frame = self.circle = self.colony = None
        self.status.set("STANDBY  已断开"); self.detail.set("未检测到培养皿")
        self.entry.config(state="normal"); self.connect_btn.config(text="连接视频流")

    def poll(self):
        try:
            while True:
                kind, data = self.events.get_nowait()
                if kind == "connected": self.status.set("ONLINE  视频流已连接")
                elif kind == "error": messagebox.showerror("视频流错误", data); self.disconnect()
                else: self.handle(*data)
        except queue.Empty: pass
        self.root.after(15, self.poll)

    def handle(self, frame, timestamp):
        self.frame = frame; self.counter += 1
        if self.last_frame:
            now_fps = 1 / max(timestamp - self.last_frame, .001)
            self.fps = now_fps if not self.fps else self.fps * .88 + now_fps * .12
        self.last_frame = timestamp
        # OpenCV 不暴露所有网络流的实际传输字节数；每 15 帧以当前帧 JPEG
        # 编码大小估算实时视频码率，对 MJPEG/IP 摄像头具有较好参考价值。
        if self.counter % 15 == 1:
            ok, encoded = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
            if ok and self.fps:
                sample = encoded.nbytes * 8 * self.fps / 1_000_000
                self.bitrate_mbps = sample if not self.bitrate_mbps else self.bitrate_mbps * .7 + sample * .3
        if self.counter % 3 == 1:
            found = detect(frame)
            if found:
                if self.circle:
                    self.circle = tuple(self.circle[i] * .72 + found[i] * .28 for i in range(3))
                else: self.circle = found
                self.last_seen = time.monotonic()
            elif time.monotonic() - self.last_seen > .45:
                self.circle = self.colony = None
        # 菌落分割比圆检测更耗时，降低刷新频率；框间采用最近结果保持稳定。
        if self.circle and self.counter % 9 == 1:
            try:
                diameter_mm = float(self.dish_mm.get())
                self.colony = core.measure_colony(frame, self.circle, diameter_mm, analysis_max=700)
            except (ValueError, TypeError):
                self.colony = None
        self.render(frame)
        if self.circle:
            x, y, r = self.circle; self.status.set("LOCKED  培养皿已锁定")
            self.detail.set(f"圆心  ({x:.0f}, {y:.0f})\n直径  {r*2:.0f} px")
        else:
            self.status.set("SCANNING  正在搜索…"); self.detail.set("请将完整培养皿移入画面")

    def render(self, frame):
        # 先把纯视频缩放到窗口显示尺寸，再绘制 UI。这样字体、线宽和
        # 信息栏使用的是屏幕像素，不会随 720p/1080p/4K 串流一起缩放。
        source_h, source_w = frame.shape[:2]
        cw, ch = max(1, self.canvas.winfo_width()), max(1, self.canvas.winfo_height())
        display_scale = min(cw / source_w, ch / source_h)
        display_w = max(1, int(source_w * display_scale))
        display_h = max(1, int(source_h * display_scale))
        image = cv2.resize(frame, (display_w, display_h), interpolation=cv2.INTER_AREA)

        if self.circle:
            source_x, source_y, source_r = self.circle
            x = int(source_x * display_scale)
            y = int(source_y * display_scale)
            r = int(source_r * display_scale)
            color = (255, 193, 79)
            half = int(r * 1.03)
            left, top, right, bottom = x-half, y-half, x+half, y+half
            cv2.rectangle(image, (left, top), (right, bottom), color, 2, cv2.LINE_AA)

            # 标签字号固定；数值仍展示原始视频坐标和原始像素直径。
            text = f"CENTER {source_x:.0f},{source_y:.0f}  DIA {source_r*2:.0f}px"
            font_scale, thickness, pad = .48, 1, 8
            (tw, th), baseline = cv2.getTextSize(
                text, cv2.FONT_HERSHEY_SIMPLEX, font_scale, thickness
            )
            label_right = min(display_w - 2, right)
            label_left = max(0, label_right - tw - pad * 2)
            label_bottom = top if top >= th + baseline + pad * 2 else min(display_h, top + th + baseline + pad * 2)
            label_top = max(0, label_bottom - th - baseline - pad * 2)
            overlay = image.copy()
            cv2.rectangle(overlay, (label_left, label_top), (label_right, label_bottom), (37,37,38), -1)
            cv2.addWeighted(overlay, .86, image, .14, 0, image)
            text_y = label_top + pad + th
            cv2.putText(image, text, (label_left + pad, text_y), cv2.FONT_HERSHEY_SIMPLEX,
                        font_scale, (220,220,220), thickness, cv2.LINE_AA)

            if self.colony:
                bx, by, bw, bh = self.colony["bbox"]
                bl = int(bx*display_scale); bt = int(by*display_scale)
                br = int((bx+bw)*display_scale); bb = int((by+bh)*display_scale)
                colony_color = (113, 190, 255)
                dashed_rectangle(image, bl, bt, br, bb, colony_color)
                # 十字测量线：水平径、垂直径。
                mx, my = int((bl+br)/2), int((bt+bb)/2)
                cv2.line(image, (bl,my), (br,my), colony_color, 1, cv2.LINE_AA)
                cv2.line(image, (mx,bt), (mx,bb), colony_color, 1, cv2.LINE_AA)
                measure_text = (f"COLONY  H {self.colony['horizontal_mm']:.2f} mm  "
                                f"V {self.colony['vertical_mm']:.2f} mm  "
                                f"AVG {self.colony['mean_mm']:.2f} mm")
                (mw, mh), mb = cv2.getTextSize(measure_text, cv2.FONT_HERSHEY_SIMPLEX, .48, 1)
                # 优先显示在培养皿框右侧；空间不足时显示在框内右上方。
                info_x = right+8 if right+mw+24 < display_w else max(left+6, right-mw-16)
                info_y = max(mh+14, min(display_h-50, top+30))
                info_overlay = image.copy()
                cv2.rectangle(info_overlay, (info_x,info_y-mh-10),
                              (min(display_w-2,info_x+mw+14),info_y+6), (37,37,38), -1)
                cv2.addWeighted(info_overlay, .86, image, .14, 0, image)
                cv2.putText(image, measure_text, (info_x+7,info_y), cv2.FONT_HERSHEY_SIMPLEX,
                            .48, (113,190,255), 1, cv2.LINE_AA)

        # 底栏高度、字号、边距全部是固定显示像素。
        bar_h = 38
        overlay = image.copy()
        cv2.rectangle(overlay, (0, display_h-bar_h), (display_w, display_h), (24,24,24), -1)
        cv2.addWeighted(overlay, .86, image, .14, 0, image)
        metrics = (f"FPS  {self.fps:4.1f}     BITRATE  {self.bitrate_mbps:5.2f} Mbps (EST.)"
                   f"     RESOLUTION  {source_w} x {source_h}")
        cv2.putText(image, metrics, (16, display_h-12), cv2.FONT_HERSHEY_SIMPLEX,
                    .52, (210,210,210), 1, cv2.LINE_AA)
        self.photo=ImageTk.PhotoImage(Image.fromarray(cv2.cvtColor(image,cv2.COLOR_BGR2RGB)))
        self.canvas.delete("all"); self.canvas.create_image(cw//2,ch//2,image=self.photo)

    def capture(self):
        if self.frame is None or self.circle is None:
            messagebox.showwarning("尚未锁定", "请先连接视频流并让程序锁定培养皿。")
            return
        stamp=datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
        core.write_image(self.output/f"{stamp}_原图.jpg",self.frame)
        core.write_image(self.output/f"{stamp}_培养皿.png",core.crop_square(self.frame,self.circle,.03,0))
        self.status.set("CAPTURED  已保存")
        messagebox.showinfo("捕获成功",f"原图和 1:1 裁图已保存至：\n{self.output}")

    def open_folder(self):
        self.output.mkdir(parents=True,exist_ok=True); os.startfile(self.output)

    def close(self):
        if self.stream: self.stream.stop()
        self.root.destroy()


if __name__ == "__main__":
    root=tk.Tk(); App(root); root.mainloop()

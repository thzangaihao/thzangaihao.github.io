#!/usr/bin/env python3
"""Generate a one-dimensional pLDDT confidence map from AlphaFold output."""

from __future__ import annotations

import argparse
import json
import math
import shlex
import sys
from collections import OrderedDict
from pathlib import Path
from xml.sax.saxutils import escape


COLORS = {
    "very_high": "#326bf6",
    "confident": "#5fcced",
    "low": "#f4ed51",
    "very_low": "#e0883a",
}


def choose_file(title: str, patterns: list[tuple[str, str]]) -> Path | None:
    """Open a file selection dialog, with a terminal fallback."""
    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        filename = filedialog.askopenfilename(title=title, filetypes=patterns)
        root.destroy()
        return Path(filename) if filename else None
    except Exception:
        value = input(f"{title}\n请输入文件路径（直接回车取消）：").strip().strip('"')
        return Path(value) if value else None


def color_for_score(score: float) -> str:
    if score >= 90:
        return COLORS["very_high"]
    if score >= 70:
        return COLORS["confident"]
    if score >= 50:
        return COLORS["low"]
    return COLORS["very_low"]


def parse_cif_atom_residues(cif_path: Path) -> list[tuple[str, str, bool]]:
    """Return chain, residue ID and protein status for each CIF atom row."""
    lines = cif_path.read_text(encoding="utf-8", errors="replace").splitlines()
    index = 0

    while index < len(lines):
        if lines[index].strip() != "loop_":
            index += 1
            continue

        index += 1
        columns: list[str] = []
        while index < len(lines) and lines[index].lstrip().startswith("_"):
            columns.append(lines[index].strip().split()[0])
            index += 1

        if "_atom_site.group_PDB" not in columns:
            continue

        def find_column(*names: str) -> int:
            for name in names:
                if name in columns:
                    return columns.index(name)
            raise ValueError(f"CIF 缺少必要字段：{' 或 '.join(names)}")

        chain_col = find_column("_atom_site.label_asym_id", "_atom_site.auth_asym_id")
        residue_col = find_column("_atom_site.label_seq_id", "_atom_site.auth_seq_id")
        group_col = columns.index("_atom_site.group_PDB")
        rows: list[tuple[str, str, bool]] = []

        while index < len(lines):
            stripped = lines[index].strip()
            if (
                not stripped
                or stripped == "#"
                or stripped == "loop_"
                or stripped.startswith("_")
            ):
                break

            fields = shlex.split(stripped, posix=True)
            if len(fields) < len(columns):
                raise ValueError("CIF 的 atom_site 行包含无法解析的跨行字段。")

            group = fields[group_col].upper()
            if group in {"ATOM", "HETATM"}:
                residue_id = fields[residue_col]
                if residue_id not in {".", "?"}:
                    rows.append(
                        (fields[chain_col], residue_id, group == "ATOM")
                    )
            index += 1

        if rows:
            return rows

    raise ValueError("CIF 中未找到可用的 _atom_site 原子记录。")


def average_atom_scores(
    scores: list[float],
    atom_rows: list[tuple[str, str, bool]],
) -> tuple[list[float], list[str]]:
    """Average atom-level pLDDT values for each protein residue."""
    if len(scores) != len(atom_rows):
        raise ValueError(
            f"JSON 有 {len(scores)} 个原子 pLDDT，但 CIF 有 "
            f"{len(atom_rows)} 个原子记录；二者可能不是配套文件。"
        )

    grouped: OrderedDict[tuple[str, str], list[float]] = OrderedDict()
    for (chain, residue_id, is_protein), score in zip(atom_rows, scores):
        if is_protein:
            grouped.setdefault((chain, residue_id), []).append(float(score))

    if not grouped:
        raise ValueError("CIF 中没有找到以 ATOM 标记的蛋白质残基。")

    residue_scores = [sum(values) / len(values) for values in grouped.values()]
    chains = [chain for chain, _ in grouped]
    return residue_scores, chains


def find_matching_cif(json_path: Path) -> Path | None:
    """Find the companion model CIF used by AlphaFold 3 output naming."""
    stem = json_path.stem
    prefixes = [
        stem.rsplit("_full_data_", 1)[0],
        stem.rsplit("_summary_confidences_", 1)[0],
    ]
    candidates: list[Path] = []
    for prefix in dict.fromkeys(prefixes):
        candidates.extend(sorted(json_path.parent.glob(f"{prefix}_model_*.cif")))

    unique = list(dict.fromkeys(candidates))
    return unique[0] if len(unique) == 1 else None


def extract_residue_scores(
    data: dict,
    json_path: Path,
    cif_path: Path | None = None,
) -> tuple[list[float], list[str]]:
    """Read residue-level values directly or aggregate atom-level values."""
    for key in ("plddts", "plddt", "residue_plddts", "residue_plddt"):
        values = data.get(key)
        if isinstance(values, list) and values and not isinstance(values[0], list):
            chains = data.get("token_chain_ids", [""] * len(values))
            if not isinstance(chains, list) or len(chains) != len(values):
                chains = [""] * len(values)
            return [float(value) for value in values], [str(c) for c in chains]

    atom_scores = data.get("atom_plddts")
    if not isinstance(atom_scores, list) or not atom_scores:
        raise ValueError(
            "JSON 中未找到 plddt、plddts、residue_plddt 或 atom_plddts 数组。"
        )

    if cif_path is None:
        cif_path = find_matching_cif(json_path)
        if cif_path is not None:
            print(f"已自动匹配 CIF：{cif_path.name}")

    if cif_path is None:
        cif_path = choose_file(
            "该 JSON 是原子级置信度，请选择配套的 AlphaFold 模型 CIF 文件",
            [("mmCIF files", "*.cif"), ("All files", "*.*")],
        )
    if cif_path is None:
        raise RuntimeError("已取消 CIF 文件选择，未生成图片。")
    if not cif_path.is_file():
        raise FileNotFoundError(f"找不到 CIF 文件：{cif_path}")

    atom_rows = parse_cif_atom_residues(cif_path)
    return average_atom_scores([float(v) for v in atom_scores], atom_rows)


def nice_tick_step(length: int) -> int:
    target = max(length / 10, 1)
    magnitude = 10 ** math.floor(math.log10(target))
    normalized = target / magnitude
    multiplier = (
        1
        if normalized <= 1
        else 2
        if normalized <= 2
        else 5
        if normalized <= 5
        else 10
    )
    return int(multiplier * magnitude)


def chain_ranges(chains: list[str]) -> list[tuple[str, int, int]]:
    if not chains or not any(chains):
        return []

    ranges: list[tuple[str, int, int]] = []
    start = 0
    for index in range(1, len(chains) + 1):
        if index == len(chains) or chains[index] != chains[start]:
            ranges.append((chains[start], start, index))
            start = index
    return ranges


def color_runs(scores: list[float]) -> list[tuple[int, int, str]]:
    """Combine adjacent residues of the same class into gap-free color blocks."""
    runs: list[tuple[int, int, str]] = []
    start = 0
    color = color_for_score(scores[0])
    for index in range(1, len(scores)):
        next_color = color_for_score(scores[index])
        if next_color != color:
            runs.append((start, index, color))
            start = index
            color = next_color
    runs.append((start, len(scores), color))
    return runs


def build_svg(scores: list[float], chains: list[str], title: str) -> str:
    count = len(scores)
    plot_width = max(900, min(2400, count * 4))
    left, right = 80, 35
    width = left + plot_width + right
    height = 320
    bar_y, bar_height = 105, 64
    unit = plot_width / count
    tick_step = nice_tick_step(count)

    parts = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="#ffffff"/>',
        '<style>'
        'text{font-family:Arial,"Microsoft YaHei",sans-serif;fill:#222}'
        '.tick{font-size:12px}.legend{font-size:13px}'
        '.title{font-size:19px;font-weight:600}'
        '.chain{font-size:12px;font-weight:600}'
        '.color-map{shape-rendering:crispEdges}'
        '</style>',
        f'<text class="title" x="{width / 2:.2f}" y="34" text-anchor="middle">'
        f'{escape(title)}</text>',
        f'<text x="{width / 2:.2f}" y="59" text-anchor="middle" font-size="13">'
        f'{count} amino acid residues</text>',
        '<g class="color-map">',
    ]

    # One rectangle per continuous color run avoids anti-aliased white seams.
    for start, end, color in color_runs(scores):
        x = left + start * unit
        run_width = (end - start) * unit
        parts.append(
            f'<rect x="{x:.4f}" y="{bar_y}" width="{run_width:.4f}" '
            f'height="{bar_height}" fill="{color}"/>'
        )
    parts.append("</g>")

    # Transparent hit areas preserve per-residue hover information.
    parts.append('<g fill="transparent" stroke="none">')
    for index, score in enumerate(scores):
        x = left + index * unit
        chain_text = (
            f", Chain {escape(str(chains[index]))}"
            if index < len(chains) and chains[index]
            else ""
        )
        parts.append(
            f'<rect x="{x:.4f}" y="{bar_y}" width="{unit:.4f}" '
            f'height="{bar_height}"><title>Residue {index + 1}{chain_text}: '
            f'pLDDT {score:.2f}</title></rect>'
        )
    parts.append("</g>")

    parts.append(
        f'<rect x="{left}" y="{bar_y}" width="{plot_width}" height="{bar_height}" '
        'fill="none" stroke="#333" stroke-width="1"/>'
    )

    tick_positions = list(range(1, count + 1, tick_step))
    if tick_positions[-1] != count:
        tick_positions.append(count)
    for residue in tick_positions:
        x = left + (residue - 0.5) * unit
        parts.extend(
            [
                f'<line x1="{x:.2f}" y1="{bar_y + bar_height}" x2="{x:.2f}" '
                f'y2="{bar_y + bar_height + 7}" stroke="#333"/>',
                f'<text class="tick" x="{x:.2f}" y="{bar_y + bar_height + 23}" '
                f'text-anchor="middle">{residue}</text>',
            ]
        )

    for chain, start, end in chain_ranges(chains):
        x1 = left + start * unit
        x2 = left + end * unit
        if start:
            parts.append(
                f'<line x1="{x1:.2f}" y1="{bar_y - 5}" x2="{x1:.2f}" '
                f'y2="{bar_y + bar_height + 5}" stroke="#111" stroke-width="1.5"/>'
            )
        parts.append(
            f'<text class="chain" x="{(x1 + x2) / 2:.2f}" y="{bar_y - 12}" '
            f'text-anchor="middle">Chain {escape(chain)}</text>'
        )

    legend = [
        (COLORS["very_high"], "pLDDT ≥ 90"),
        (COLORS["confident"], "70 ≤ pLDDT < 90"),
        (COLORS["low"], "50 ≤ pLDDT < 70"),
        (COLORS["very_low"], "pLDDT < 50"),
    ]
    legend_width = 190
    legend_start = (width - legend_width * len(legend)) / 2
    legend_y = 250
    for index, (color, label) in enumerate(legend):
        x = legend_start + index * legend_width
        parts.append(
            f'<rect x="{x:.2f}" y="{legend_y}" width="22" height="15" '
            f'fill="{color}" shape-rendering="crispEdges"/>'
        )
        parts.append(
            f'<text class="legend" x="{x + 29:.2f}" y="{legend_y + 13}">'
            f'{escape(label)}</text>'
        )

    parts.append("</svg>")
    return "\n".join(parts)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="将 AlphaFold pLDDT 置信度绘制为一维 SVG 色带。"
    )
    parser.add_argument("json", nargs="?", type=Path, help="置信度 JSON 文件")
    parser.add_argument("--cif", type=Path, help="配套的模型 CIF 文件")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    json_path = args.json or choose_file(
        "选择 AlphaFold pLDDT 置信度 JSON 文件",
        [("JSON files", "*.json"), ("All files", "*.*")],
    )
    if json_path is None:
        print("已取消文件选择。")
        return 0
    if not json_path.is_file():
        print(f"错误：找不到文件：{json_path}", file=sys.stderr)
        return 1

    try:
        with json_path.open("r", encoding="utf-8") as file:
            data = json.load(file)

        scores, chains = extract_residue_scores(data, json_path, args.cif)
        if not scores:
            raise ValueError("未读取到任何残基 pLDDT 分数。")
        if any(not math.isfinite(score) for score in scores):
            raise ValueError("pLDDT 数组包含非有限数值。")

        output_path = (
            Path(__file__).resolve().parent / f"{json_path.stem}_plddt.svg"
        )
        svg = build_svg(scores, chains, f"AlphaFold pLDDT: {json_path.stem}")
        output_path.write_text(svg, encoding="utf-8")
    except (OSError, ValueError, TypeError, json.JSONDecodeError, RuntimeError) as exc:
        print(f"错误：{exc}", file=sys.stderr)
        return 1

    print(f"完成：共绘制 {len(scores)} 个氨基酸残基")
    print(f"SVG 已保存至：{output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# 1. 安装并加载必要的包
# install.packages("ggplot2") # 如果你还没有安装 ggplot2，请取消开头的注释先进行安装
library(ggplot2)

# 2. 读取数据
# 你的数据第一列似乎是序号，通过 row.names = 1 将其直接设为行名
pca_data <- read.csv("示例2.csv", row.names = 1)

# 3. 使用 ggplot2 绘制 PCA 散点图
p <- ggplot(pca_data, aes(x = STEM, y = LA)) +
  # 绘制散点：可以调整大小(size)和透明度(alpha)，透明度在数据点增多时能有效避免重叠造成的视觉盲区
  geom_point(color = "#4C72B0", size = 2.5, alpha = 0.7) +
  
  # 使用经典的黑白边框主题，非常适合学术论文发表
  theme_bw() + 
  
  # 核心设置：1:1 的成图要求
  # coord_fixed(ratio = 1) 会强制 X 轴和 Y 轴的单位物理长度绝对相等（PCA标准做法）
  coord_fixed(ratio = 1) + 
  
  theme(
    # aspect.ratio = 1 保证绘图的外框一定是正方形的 1:1 比例
    aspect.ratio = 1,
    # 标题居中并加粗
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14)
  ) +
  
  # 添加标题和坐标轴标签
  labs(
    x = "STEM",
    y = "LA"
  )

ggsave(
  filename = "1.svg", 
  plot = p, 
  width = 6,    # 宽设为6
  height = 6,   # 高设为6，保持1:1的画板比例
  device = "svg"
)

# 5. 输出/保存为 1:1 的高质量图片文件
# width 和 height 设定为相同数值(如 6x6)，dpi 设为 300 满足学术期刊的高分辨率要求
# ggsave("PCA_Result.png", plot = p, width = 6, height = 6, dpi = 300)
# 若以后点数极多（如上万个细胞），强烈建议保存为 PDF 矢量图，缩放不失真：
# ggsave("PCA_Result.pdf", plot = p, width = 6, height = 6)
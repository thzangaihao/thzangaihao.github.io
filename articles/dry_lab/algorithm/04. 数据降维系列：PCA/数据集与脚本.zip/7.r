# 1. 加载必要的包
library(plotly)
library(htmlwidgets)

# ==========================================
# 步骤 1：生成嵌套球体数据集 (纯正的 PCA 杀手)
# ==========================================
set.seed(42)
n_points <- 300 

# 生成内部小球 (Inner Sphere)
u1 <- runif(n_points, 0, 2*pi)
v1 <- runif(n_points, -1, 1)
r1 <- 5 # 小球半径为 5
x1 <- r1 * sqrt(1 - v1^2) * cos(u1) + rnorm(n_points, 0, 0.3)
y1 <- r1 * sqrt(1 - v1^2) * sin(u1) + rnorm(n_points, 0, 0.3)
z1 <- r1 * v1 + rnorm(n_points, 0, 0.3)

# 生成外部大球 (Outer Sphere)
u2 <- runif(n_points, 0, 2*pi)
v2 <- runif(n_points, -1, 1)
r2 <- 15 # 大球半径为 15
x2 <- r2 * sqrt(1 - v2^2) * cos(u2) + rnorm(n_points, 0, 0.5)
y2 <- r2 * sqrt(1 - v2^2) * sin(u2) + rnorm(n_points, 0, 0.5)
z2 <- r2 * v2 + rnorm(n_points, 0, 0.5)

df <- data.frame(
  X = c(x1, x2),
  Y = c(y1, y2),
  Z = c(z1, z2),
  Group = c(rep("Inner Sphere", n_points), rep("Outer Sphere", n_points))
)

# ==========================================
# 步骤 2：对嵌套球执行 PCA 并计算 3D 投影坐标
# ==========================================
X_mat <- as.matrix(df[, 1:3])
pca_res <- prcomp(X_mat, center = TRUE, scale. = FALSE)
means <- colMeans(X_mat)

proj_3d <- pca_res$x[, 1:2] %*% t(pca_res$rotation[, 1:2])
proj_3d <- sweep(proj_3d, 2, means, "+")

df$X_proj <- proj_3d[, 1]
df$Y_proj <- proj_3d[, 2]
df$Z_proj <- proj_3d[, 3]

# ==========================================
# 步骤 3：构建计算组件（平整投影面与实线连线）
# ==========================================
# 1. 计算 PCA 投影平面
pc1_bnd <- c(-1, 1) * max(abs(pca_res$x[, 1])) * 1.2
pc2_bnd <- c(-1, 1) * max(abs(pca_res$x[, 2])) * 1.2

plane_x <- matrix(0, 2, 2); plane_y <- matrix(0, 2, 2); plane_z <- matrix(0, 2, 2)
for(i in 1:2) { 
  for(j in 1:2) { 
    pt <- means + pc1_bnd[j] * pca_res$rotation[, 1] + pc2_bnd[i] * pca_res$rotation[, 2]
    plane_x[i, j] <- pt[1]; plane_y[i, j] <- pt[2]; plane_z[i, j] <- pt[3]
  }
}

# 2. 构建投影连线 (实线对齐)
line_df <- data.frame(
  x = c(rbind(df$X, df$X_proj)),
  y = c(rbind(df$Y, df$Y_proj)),
  z = c(rbind(df$Z, df$Z_proj)),
  pair_id = rep(1:nrow(df), each = 2)
)

# 【核心要求】：拒绝杂乱的渐变色，使用最严谨的对比单色
group_colors <- c("Inner Sphere" = "#FF7F0E", "Outer Sphere" = "#1F77B4")

# ==========================================
# 步骤 4：生成 3D 交互式可视化图
# ==========================================
p_fail <- plot_ly() %>%
  
  # a. 绘制降维平面 (半透明深灰色)
  add_surface(x = plane_x, y = plane_y, z = plane_z,
              opacity = 0.3, colorscale = list(c(0, 1), c("#999999", "#999999")), 
              showscale = FALSE, hoverinfo = "none", name = "PCA Plane") %>%
  
  # b. 绘制原始的 3D 嵌套球 (点悬浮在空中)
  add_markers(data = df, x = ~X, y = ~Y, z = ~Z, color = ~Group, colors = group_colors,
              marker = list(size = 2, opacity = 0.3), name = "Original 3D Data") %>%
  
  # c. 绘制降维投影点 (落在切面上，使用 "cross" 十字形状区别原始点)
  add_markers(data = df, x = ~X_proj, y = ~Y_proj, z = ~Z_proj, color = ~Group, colors = group_colors,
              marker = list(size = 3, opacity = 1, symbol = "cross"), name = "2D Projection") %>%
  
  # d. 投影连线 (实线连接)
  add_trace(data = line_df, x = ~x, y = ~y, z = ~z, split = ~pair_id,
            type = 'scatter3d', mode = 'lines',
            line = list(color = "rgba(100, 100, 100, 0.4)", width = 1.2, dash = 'solid'),
            showlegend = FALSE, hoverinfo = "none") %>%
  
  layout(title = "PCA Complete Failure: Concentric Spheres",
         scene = list(
           xaxis = list(title = "X"),
           yaxis = list(title = "Y"),
           zaxis = list(title = "Z")
         ))

# 保存为 HTML 网页
saveWidget(p_fail, "PCA_Complete_Failure.html")

print("PCA完全失效的嵌套球体 3D 网页已生成！")
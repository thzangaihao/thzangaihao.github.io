# 1. 加载必要的包
library(ggplot2)
library(svglite)

# 2. 读取数据 (确保示例1.csv在当前目录)
pca_data <- read.csv("示例2.csv", row.names = 1)

# 3. 计算 X 轴投影坐标
# 投影到 X 轴，意味着 X 坐标不变，Y 坐标全为 0
pca_data$x_proj <- pca_data$STEM
pca_data$y_proj <- 0

# 4. 绘制 2D 散点图与 X 轴投影的合并图
p_x_axis_proj <- ggplot(pca_data) +
  
  # a. 添加原点参考线
  # 这里将 X 轴 (yintercept = 0) 作为投影的基准线，特意加深加粗
  geom_hline(yintercept = 0, color = "#333333", linetype = "solid", linewidth = 0.8) +
  geom_vline(xintercept = 0, color = "grey85", linetype = "solid", linewidth = 0.5) +
  
  # b. 添加投影路径（垂直于 X 轴的虚线段）
  # 放在数据点下方，作为视觉辅助
  geom_segment(aes(x = STEM, y = LA, xend = x_proj, yend = y_proj), 
               color = "grey65", linetype = "dashed", alpha = 0.5, linewidth = 0.4) +
  
  # c. 绘制原始二维数据点 (学术高雅蓝)
  geom_point(aes(x = STEM, y = LA), color = "#1F77B4", size = 2.5, alpha = 0.7) +
  
  # d. 绘制落在 X 轴上的投影点 (学术活力橙)
  geom_point(aes(x = x_proj, y = y_proj), color = "#FF7F0E", size = 2.5, alpha = 0.9) +
  
  # e. 经典的黑白学术主题
  theme_bw() +
  
  # f. 强制设置范围为 -100 到 +100，锁定 1:1 的几何空间比例
  coord_fixed(ratio = 1, xlim = c(0, 100), ylim = c(0, 100)) + 
  
  # g. 细节美观性微调
  theme(
    aspect.ratio = 1,                               
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14, color = "#222222"),
    axis.title = element_text(face = "bold", size = 11, color = "#222222"),
    axis.text = element_text(size = 10, color = "#333333"),
    panel.grid.major = element_line(color = "grey95", linewidth = 0.5), 
    panel.grid.minor = element_blank()                                 
  ) +
  
  # 标签设置
  labs(
    x = "STEM",
    y = "LA"
  )

# 5. 导出为高分辨率的 SVG 矢量图
ggsave(
  filename = "4.svg", 
  plot = p_x_axis_proj, 
  width = 6.5,    
  height = 6.5, 
  device = "svg"
)

print("X轴合并投影图的 SVG 已成功生成！")
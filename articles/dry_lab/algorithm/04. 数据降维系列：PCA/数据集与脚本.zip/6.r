# 1. 加载必要的包
library(ggplot2)
library(svglite)
library(plotly)
library(htmlwidgets)

# ==========================================
# 步骤 1：模拟 3D 生物学数据 (3个基因, 3个分组)
# ==========================================
set.seed(42)
n_samples <- 50 

wt_data   <- data.frame(Gene1=rnorm(n_samples, 10, 2), Gene2=rnorm(n_samples, 15, 3), Gene3=rnorm(n_samples, 5, 1.5), Group="Wild-Type")
mutA_data <- data.frame(Gene1=rnorm(n_samples, 20, 2.5), Gene2=rnorm(n_samples, 5, 2), Gene3=rnorm(n_samples, 15, 3), Group="Mutant-A")
mutB_data <- data.frame(Gene1=rnorm(n_samples, 5, 2), Gene2=rnorm(n_samples, 25, 2.5), Gene3=rnorm(n_samples, 10, 2), Group="Mutant-B")

mock_data <- rbind(wt_data, mutA_data, mutB_data)
rownames(mock_data) <- paste0("Cell_", 1:nrow(mock_data))
X <- as.matrix(mock_data[, 1:3])

# ==========================================
# 步骤 2：执行 PCA 降维与逆向投影
# ==========================================
pca_res <- prcomp(X, center = TRUE, scale. = FALSE)
df <- mock_data
df$PC1 <- pca_res$x[, 1]
df$PC2 <- pca_res$x[, 2]

# 计算在三维空间中的投影坐标
means <- colMeans(X)
proj_3d <- pca_res$x[, 1:2] %*% t(pca_res$rotation[, 1:2])
proj_3d <- sweep(proj_3d, 2, means, "+")

df$Gene1_proj <- proj_3d[, 1]
df$Gene2_proj <- proj_3d[, 2]
df$Gene3_proj <- proj_3d[, 3]

group_colors <- c("Wild-Type" = "#1F77B4", "Mutant-A" = "#FF7F0E", "Mutant-B" = "#2CA02C")

# ==========================================
# 步骤 3：输出文件一 —— 原始 3D 分布图 (HTML)
# ==========================================
p1_3d <- plot_ly(df, x = ~Gene1, y = ~Gene2, z = ~Gene3, color = ~Group, colors = group_colors,
                 type = "scatter3d", mode = "markers",
                 marker = list(size = 2, opacity = 0.3)) %>%
  layout(title = "1. Original 3D Data Distribution",
         scene = list(xaxis = list(title = "Gene 1"),
                      yaxis = list(title = "Gene 2"),
                      zaxis = list(title = "Gene 3")))

saveWidget(p1_3d, "PCA_Plot1_Original_3D.html")


# ==========================================
# 步骤 4：输出文件二 —— 优化版的 3D 投影过程图 (HTML)
# ==========================================
# 1. 计算半透明二维投影面的 3D 边界坐标
pc1_bnd <- c(-1, 1) * max(abs(pca_res$x[, 1])) * 1.3
pc2_bnd <- c(-1, 1) * max(abs(pca_res$x[, 2])) * 1.3

plane_x <- matrix(0, nrow = 2, ncol = 2)
plane_y <- matrix(0, nrow = 2, ncol = 2)
plane_z <- matrix(0, nrow = 2, ncol = 2)

for(i in 1:2) { 
  for(j in 1:2) { 
    pt <- means + pc1_bnd[j] * pca_res$rotation[, 1] + pc2_bnd[i] * pca_res$rotation[, 2]
    plane_x[i, j] <- pt[1]
    plane_y[i, j] <- pt[2]
    plane_z[i, j] <- pt[3]
  }
}

# 2. 构建绝对稳妥的投影线数据框
# 为每个细胞的起点(原始坐标)和终点(投影坐标)赋予同一个 pair_id
line_df <- data.frame(
  x = c(rbind(df$Gene1, df$Gene1_proj)),
  y = c(rbind(df$Gene2, df$Gene2_proj)),
  z = c(rbind(df$Gene3, df$Gene3_proj)),
  pair_id = rep(1:nrow(df), each = 2) 
)

# 3. 绘制带有透明切面的 3D 图
p2_combined <- plot_ly() %>%
  add_surface(x = plane_x, y = plane_y, z = plane_z,
              opacity = 0.25, colorscale = list(c(0, 1), c("#AAAAAA", "#AAAAAA")), 
              showscale = FALSE, hoverinfo = "none", name = "PCA Plane") %>%
  add_markers(data = df, x = ~Gene1, y = ~Gene2, z = ~Gene3, color = ~Group, colors = group_colors,
              marker = list(size = 2, opacity = 0.3), name = "Original Points") %>%
  add_markers(data = df, x = ~Gene1_proj, y = ~Gene2_proj, z = ~Gene3_proj, color = ~Group, colors = group_colors,
              marker = list(size = 1, opacity = 1), name = "Projected Plane") %>%

  add_trace(data = line_df, x = ~x, y = ~y, z = ~z, split = ~pair_id,
            type = 'scatter3d', mode = 'lines',
            line = list(color = "rgba(0, 0, 0, 0.6)", width = 1, dash = 'soild'),
            showlegend = FALSE, hoverinfo = "none", name = "Projection Path") %>%
            
  layout(title = "2. 3D Projection Process (with PCA Plane)",
         scene = list(xaxis = list(title = "Gene 1"),
                      yaxis = list(title = "Gene 2"),
                      zaxis = list(title = "Gene 3")))

saveWidget(p2_combined, "PCA_Plot2_Optimized_Combined.html")



# ==========================================
# 步骤 5：输出文件三 —— 最终发表级 2D 散点图 (SVG)
# ==========================================
variance_explained <- summary(pca_res)$importance[2, 1:2] * 100

p3_2d <- ggplot(df, aes(x = PC1, y = PC2, color = Group)) +
  geom_hline(yintercept = 0, linetype = "solid", color = "grey80") +
  geom_vline(xintercept = 0, linetype = "solid", color = "grey80") +
  geom_point(size = 3, alpha = 0.8) +
  scale_color_manual(values = group_colors) +
  theme_bw() + 
  coord_fixed(ratio = 1) + 
  theme(
    aspect.ratio = 1,
    plot.title = element_text(hjust = 0.5, face = "bold"),
    legend.position = "right"
  ) +
  labs(title = "3. Final 2D PCA Dimensionality Reduction",
       x = sprintf("PC1 (%.1f%% Variance)", variance_explained[1]),
       y = sprintf("PC2 (%.1f%% Variance)", variance_explained[2]))

ggsave("PCA_Plot3_Final_2D.svg", plot = p3_2d, width = 6.5, height = 6, device = "svg")

print("全套工作流执行完毕！已生成 2 个 HTML 和 1 个 SVG 文件。")
# 1. 加载必要的包
library(ggplot2)
library(svglite)

# 2. 读取数据 (确保示例1.csv在当前目录)
pca_data <- read.csv("示例2.csv", row.names = 1)

# 3. 计算投影坐标
pca_data$x_proj <- (pca_data$STEM - pca_data$LA) / 2
pca_data$y_proj <- (pca_data$LA - pca_data$STEM) / 2

# 4. 绘制高颜值 2D 综合投影图
p_elegant <- ggplot(pca_data) +
  
  # a. 【美化新增】添加经过原点 (0,0) 的细十字参考线，使原点位置一目了然
  geom_vline(xintercept = 0, color = "grey85", linetype = "solid", linewidth = 0.5) +
  geom_hline(yintercept = 0, color = "grey85", linetype = "solid", linewidth = 0.5) +
  
  # b. 添加目标投影直线 y = -x (斜率 slope = -1, 截距 intercept = 0 完美过原点)
  geom_abline(intercept = 0, slope = -1, color = "#333333", linewidth = 0.8) +
  
  # c. 添加投影路径虚线 (调整了粗细和透明度，使其甘当绿叶)
  geom_segment(aes(x = STEM, y = LA, xend = x_proj, yend = y_proj), 
               color = "grey65", linetype = "dashed", alpha = 0.5, linewidth = 0.4) +
  
  # d. 绘制原始数据点 (选用经典的学术高雅蓝 #1F77B4)
  geom_point(aes(x = STEM, y = LA), color = "#1F77B4", size = 2.5, alpha = 0.7) +
  
  # e. 绘制直线上的投影点 (选用对比鲜明的学术活力橙 #FF7F0E)
  geom_point(aes(x = x_proj, y = y_proj), color = "#FF7F0E", size = 2.5, alpha = 0.8) +
  
  # f. 使用经典的黑白学术主题
  theme_bw() +
  
  # g. 【核心关键】：强制设置 X 轴和 Y 轴范围为 -100 到 +100，并锁定 1:1 物理比例
  coord_fixed(ratio = 1, xlim = c(-100, 100), ylim = c(-100, 100)) + 
  
  # h. 细节美观性微调
  theme(
    aspect.ratio = 1,                               # 确保画板外框是绝对的正方形 1:1
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14, color = "#222222"),
    axis.title = element_text(face = "bold", size = 11, color = "#222222"),
    axis.text = element_text(size = 10, color = "#333333"),
    panel.grid.major = element_line(color = "grey95", linewidth = 0.5), # 软化背景网格线
    panel.grid.minor = element_blank()                                 # 隐藏次要网格线，使图面更干净
  ) +
  
  # 标签设置
  labs(
    x = "STEM",
    y = "LA"
  )

# 5. 导出为高分辨率的 SVG 矢量图
ggsave(
  filename = "5.svg", 
  plot = p_elegant, 
  width = 6.5,    # 宽和高保持一致
  height = 6.5, 
  device = "svg"
)

print("固定范围且美化完成的 2D 投影图 SVG 已成功生成！")
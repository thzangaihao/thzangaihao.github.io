# 1. 加载必要的包
library(ggplot2)
library(svglite)

# 2. 读取数据 (确保文件在当前目录)
# 根据你上传的文件记录，这里以示例1.csv为例，如果你用的是示例2.csv，请自行更改文件名
pca_data <- read.csv("示例3.csv", row.names = 1)

# 3. 【核心新增】：数据中心化 (Mean Centering)
# 计算每一列的均值，并让所有数据减去均值
pca_data$STEM_centered <- pca_data$STEM - mean(pca_data$STEM)
pca_data$LA_centered <- pca_data$LA - mean(pca_data$LA)

# 4. 计算中心化后的投影坐标
# 目标直线：y = -x (此时直线穿过数据的绝对重心)
pca_data$x_proj <- (pca_data$STEM_centered - pca_data$LA_centered) / 2
pca_data$y_proj <- (pca_data$LA_centered - pca_data$STEM_centered) / 2

# 5. 绘制中心化后的 2D 综合投影图
p_centered <- ggplot(pca_data) +
  
  # a. 添加原点十字参考线（现在的(0,0)就是整团数据的物理重心）
  geom_vline(xintercept = 0, color = "grey85", linetype = "solid", linewidth = 0.5) +
  geom_hline(yintercept = 0, color = "grey85", linetype = "solid", linewidth = 0.5) +
  
  # b. 添加目标投影直线 y = -x
  geom_abline(intercept = 0, slope = -1, color = "#333333", linewidth = 0.8) +
  
  # c. 添加投影路径虚线 (注意这里的坐标换成了中心化后的数据列)
  geom_segment(aes(x = STEM_centered, y = LA_centered, xend = x_proj, yend = y_proj), 
               color = "grey65", linetype = "dashed", alpha = 0.5, linewidth = 0.4) +
  
  # d. 绘制中心化后的原始数据点 (高雅蓝)
  geom_point(aes(x = STEM_centered, y = LA_centered), color = "#1F77B4", size = 2.5, alpha = 0.7) +
  
  # e. 绘制直线上的投影点 (活力橙)
  geom_point(aes(x = x_proj, y = y_proj), color = "#FF7F0E", size = 2.5, alpha = 0.8) +
  
  # f. 学术黑白主题
  theme_bw() +
  
  # g. 强制 1:1 物理比例
  # 【微调】：因为减去均值后数据点都聚集在0附近，把范围收缩到 -60 到 +60 更好看
  coord_fixed(ratio = 1, xlim = c(-60, 60), ylim = c(-60, 60)) + 
  
  theme(
    aspect.ratio = 1,                               
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14, color = "#222222"),
    axis.title = element_text(face = "bold", size = 11, color = "#222222"),
    axis.text = element_text(size = 10, color = "#333333"),
    panel.grid.major = element_line(color = "grey95", linewidth = 0.5), 
    panel.grid.minor = element_blank()                                 
  ) +
  
  labs(
    x = "Centered STEM (x - mean)",
    y = "Centered LA (y - mean)"
  )

# 6. 导出为 SVG
ggsave(
  filename = "6.svg", 
  plot = p_centered, 
  width = 6.5,    
  height = 6.5, 
  device = "svg"
)

print("数据中心化后的投影图 SVG 已成功生成！")
# 1. 加载必要的包
library(ggplot2)
library(svglite)

# 2. 读取数据 (确保文件在当前目录)
pca_data <- read.csv("示例2.csv", row.names = 1)

# 3. 数据中心化 (Mean Centering)
# 将所有点平移，使这团数据的物理重心落在 (0,0)
pca_data$STEM_centered <- pca_data$STEM - mean(pca_data$STEM)
pca_data$LA_centered <- pca_data$LA - mean(pca_data$LA)

# 4. 计算投影到 y = x 的坐标
# 注意这里的公式变成了两坐标相加除以2
pca_data$x_proj <- (pca_data$STEM_centered + pca_data$LA_centered) / 2
pca_data$y_proj <- (pca_data$STEM_centered + pca_data$LA_centered) / 2

# 5. 绘制中心化后投影到 y=x 的 2D 综合投影图
p_centered_yx <- ggplot(pca_data) +
  
  # a. 添加原点十字参考线 (0,0)
  geom_vline(xintercept = 0, color = "grey85", linetype = "solid", linewidth = 0.5) +
  geom_hline(yintercept = 0, color = "grey85", linetype = "solid", linewidth = 0.5) +
  
  # b. 【核心修改】添加目标投影直线 y = x (截距 intercept = 0, 斜率 slope = 1)
  geom_abline(intercept = 0, slope = 1, color = "#333333", linewidth = 0.8) +
  
  # c. 添加投影路径虚线 (连接原始中心化点与直线上的投影点)
  geom_segment(aes(x = STEM_centered, y = LA_centered, xend = x_proj, yend = y_proj), 
               color = "grey65", linetype = "dashed", alpha = 0.5, linewidth = 0.4) +
  
  # d. 绘制中心化后的原始数据点 (学术高雅蓝)
  geom_point(aes(x = STEM_centered, y = LA_centered), color = "#1F77B4", size = 2.5, alpha = 0.7) +
  
  # e. 绘制直线上的投影点 (学术活力橙)
  geom_point(aes(x = x_proj, y = y_proj), color = "#FF7F0E", size = 2.5, alpha = 0.8) +
  
  # f. 学术黑白主题
  theme_bw() +
  
  # g. 强制 1:1 物理比例，锁定范围以维持稳定的视觉对比
  coord_fixed(ratio = 1, xlim = c(-60, 60), ylim = c(-60, 60)) + 
  
  theme(
    aspect.ratio = 1,                               
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14, color = "#222222"),
    axis.title = element_text(face = "bold", size = 11, color = "#222222"),
    axis.text = element_text(size = 10, color = "#333333"),
    panel.grid.major = element_line(color = "grey95", linewidth = 0.5), 
    panel.grid.minor = element_blank()                                 
  ) +
  
  labs(
    x = "Centered STEM (x - mean)",
    y = "Centered LA (y - mean)"
  )

# 6. 导出为 SVG
ggsave(
  filename = "1x.svg", 
  plot = p_centered_yx, 
  width = 6.5,    
  height = 6.5, 
  device = "svg"
)

print("数据中心化后投影到 y=x 的图表 SVG 已成功生成！")